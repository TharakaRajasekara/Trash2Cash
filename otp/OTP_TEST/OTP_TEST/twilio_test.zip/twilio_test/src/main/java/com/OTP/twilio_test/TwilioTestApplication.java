package com.OTP.twilio_test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TwilioTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(TwilioTestApplication.class, args);
	}

}
