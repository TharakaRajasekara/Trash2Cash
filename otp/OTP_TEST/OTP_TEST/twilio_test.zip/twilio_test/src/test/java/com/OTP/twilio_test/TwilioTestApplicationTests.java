package com.OTP.twilio_test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwilioTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
